/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_128(unsigned x)
{
    return x + 2445773128U;
}

unsigned getval_184()
{
    return 3284633928U;
}

void setval_340(unsigned *p)
{
    *p = 3281017058U;
}

unsigned getval_113()
{
    return 3281031256U;
}

unsigned getval_440()
{
    return 3284633928U;
}

unsigned addval_213(unsigned x)
{
    return x + 3347666986U;
}

void setval_116(unsigned *p)
{
    *p = 1002672248U;
}

void setval_104(unsigned *p)
{
    *p = 3988936908U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_493()
{
    return 3677929929U;
}

unsigned addval_159(unsigned x)
{
    return x + 2430638408U;
}

void setval_428(unsigned *p)
{
    *p = 3223377577U;
}

void setval_494(unsigned *p)
{
    *p = 3281311369U;
}

unsigned addval_143(unsigned x)
{
    return x + 3525364361U;
}

unsigned getval_224()
{
    return 3680553609U;
}

void setval_208(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_436(unsigned x)
{
    return x + 3224945033U;
}

unsigned addval_419(unsigned x)
{
    return x + 3682912921U;
}

unsigned addval_118(unsigned x)
{
    return x + 3677407881U;
}

void setval_485(unsigned *p)
{
    *p = 3224945033U;
}

unsigned addval_352(unsigned x)
{
    return x + 3286280520U;
}

unsigned addval_119(unsigned x)
{
    return x + 3224945049U;
}

void setval_259(unsigned *p)
{
    *p = 3599450502U;
}

void setval_401(unsigned *p)
{
    *p = 2227423881U;
}

unsigned getval_457()
{
    return 3380136585U;
}

unsigned getval_498()
{
    return 3281046185U;
}

unsigned getval_336()
{
    return 2429979122U;
}

void setval_397(unsigned *p)
{
    *p = 2463533509U;
}

void setval_371(unsigned *p)
{
    *p = 3285584161U;
}

void setval_413(unsigned *p)
{
    *p = 2430634824U;
}

void setval_468(unsigned *p)
{
    *p = 2425411209U;
}

unsigned addval_219(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_138(unsigned x)
{
    return x + 3534018185U;
}

unsigned getval_154()
{
    return 3232022921U;
}

void setval_101(unsigned *p)
{
    *p = 3529556361U;
}

unsigned addval_398(unsigned x)
{
    return x + 3248048000U;
}

unsigned getval_343()
{
    return 3353381192U;
}

unsigned getval_196()
{
    return 3767093352U;
}

unsigned getval_309()
{
    return 2430650696U;
}

void setval_351(unsigned *p)
{
    *p = 3676881289U;
}

void setval_293(unsigned *p)
{
    *p = 3374369289U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
